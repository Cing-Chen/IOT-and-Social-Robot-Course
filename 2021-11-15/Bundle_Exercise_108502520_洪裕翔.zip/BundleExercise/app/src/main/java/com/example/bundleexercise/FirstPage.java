package com.example.bundleexercise;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class FirstPage extends AppCompatActivity {

    EditText message_edittext;
    Button go_to_next_page_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page_first);

        initialObjects();

        go_to_next_page_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("message", message_edittext.getText().toString());

                Intent intent = new Intent();
                intent.putExtras(bundle);
                intent.setClass(FirstPage.this, SecondPage.class);
                startActivity(intent);
            }
        });
    }

    private void initialObjects() {
        message_edittext = (EditText) findViewById(R.id.message_edittext);
        go_to_next_page_button = (Button) findViewById(R.id.go_to_next_page_button);
    }
}
